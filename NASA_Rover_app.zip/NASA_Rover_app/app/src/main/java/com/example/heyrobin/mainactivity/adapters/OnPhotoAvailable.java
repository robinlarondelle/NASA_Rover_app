package com.example.heyrobin.mainactivity.adapters;

import com.example.heyrobin.mainactivity.domain.Photo;

public interface OnPhotoAvailable {
    void OnPhotoAvailable(Photo photo);
}
