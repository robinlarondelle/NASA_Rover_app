package com.example.heyrobin.mainactivity.util;

public class Tags {
    public static final int SOL_AMOUNT = 1000;
    public static final String API_KEY = "UPqNJWvjW67AhOShogbAH5iI4B3kDHKOGz4ZCKJU";
}
